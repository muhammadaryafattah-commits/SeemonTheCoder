for i in range(5):
    for j in range(i):
        print(" ", end=(""))
    for z in range(1, 6 -i):
        print(z, end=(""))
    print()